package app;

public class Car{
	
	private Engine engine;
	
	
	public void move()
	{
		System.out.println("Car is moving");
		
	}


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	
	
	

}
