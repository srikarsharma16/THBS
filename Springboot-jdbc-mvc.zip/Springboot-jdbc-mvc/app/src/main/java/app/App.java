package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	
	public static void main(String[] args) {
		
		
		Engine engine = new Engine();
		
		Car obj1 = new Car();
		//obj1.setEngine(engine);
		//obj1.move();
		
		
		System.out.println("Hello from Maven Project");
		
		ApplicationContext context =  new ClassPathXmlApplicationContext("spring.xml");
		
		Car car = (Car) context.getBean("car");
		car.move();
		
		//Bike bike= (Bike) context.getBean("bike");
		
		//bike.move();
	}

}
