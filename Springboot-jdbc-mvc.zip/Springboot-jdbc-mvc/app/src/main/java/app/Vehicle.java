package app;

public class Vehicle {

}
