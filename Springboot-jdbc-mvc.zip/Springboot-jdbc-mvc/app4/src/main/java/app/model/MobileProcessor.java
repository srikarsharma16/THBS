package app.model;

public interface MobileProcessor 
{
	void process();
}
