package app.model;

public interface CPU {

}
