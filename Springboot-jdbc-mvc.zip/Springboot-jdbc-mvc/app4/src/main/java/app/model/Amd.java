package app.model;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Amd implements MobileProcessor {
	
	@Override
	public void process()
	{
		System.out.println("Another CPU i.e. AMD");
	}

}
