package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import app.config.SpringConfig;

public class App {
	
	public static void main(String[] args) {
		
		
		System.out.println("Hello from Maven Project");
		
		//ApplicationContext context =  new ClassPathXmlApplicationContext(SpringConfig.class);
		//ApplicationContext context =  new AnnotataionConfigApplicationContext(SpringConfig.class);
		
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		Bike bike1= (Bike) context.getBean("pulsar");
		Bike bike2= (Bike) context.getBean("pulsar");
		System.out.println(bike1);
		System.out.println(bike2);
		
		System.out.println();
		
		Car car1 = context.getBean("car", Car.class);
		Car car2 = context.getBean("car", Car.class);
		System.out.println(car1);
		System.out.println(car2);
		
	}

}
