package app.config;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import app.Bike;
import app.Car;

@Configuration
@ComponentScan(basePackages = "app")
public class SpringConfig {
	
	@Bean
	public Bike getBike() {
		return new Bike();
	}
	
	@Bean
	@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public Car getCar()
	{
		return new Car();
	}
	
	
	
	

}
