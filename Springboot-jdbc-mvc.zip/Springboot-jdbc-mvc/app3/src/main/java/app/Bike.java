package app;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;


@Component("pulsar")
public class Bike {
	
	public void move()
	{
		System.out.println("Bike is moving");
	}

}
