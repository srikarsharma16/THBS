package com.srikar.SpringBoot3.repo;

public class ProductRepository {

}
