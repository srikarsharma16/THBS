package com.srikar.SpringBoot1.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.srikar.SpringBoot3.model.Customer;
import com.srikar.SpringBoot3.model.Product;

@Repository
public class CustomerDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void add(Customer customer) {
		String insertSql = "insert into customer(name,email,password) values(?,?,?)";
		
		jdbcTemplate.update(insertSql, customer.getName(), customer.getEmail(), customer.getPassword());
	}
	
	public void update(Customer customer) {
		
		String updateSql = "update customer set name=?, email=?, password=? where id=?";
		
		jdbcTemplate.update(updateSql, customer.getName(), customer.getEmail(), customer.getPassword());
		
	}
	
	public void delete(long customerId) {
		String deleteSql = "Delete from customer where id=?";
		
		jdbcTemplate.update(deleteSql, customerId);
	}

}
