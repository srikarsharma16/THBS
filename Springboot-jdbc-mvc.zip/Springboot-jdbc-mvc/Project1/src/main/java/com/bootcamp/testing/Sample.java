package com.bootcamp.testing;

import java.util.Iterator;

public class Sample {
	
	public int getMin(int[] arr) {
		int min= arr[0];
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<min)
			{
				min=arr[i];
			}
		}
		return min;
	}
	

	
	public boolean isEven(int x) {
		if(x % 2 == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public int add(int a, int v)
	{
		int c=0;
		
		return c=a+v;
	
	}

}
