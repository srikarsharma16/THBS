package com.bootcamp.testing;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class SampleTest {

	@Test
	public void test() {
		int[] arr = {6,3,9,3,6,7,5};
		
		Sample sample= new Sample();
		
		int min= sample.getMin(arr);
		
		assertEquals(3, min);
	}
	
	@Test
	public void test2()
	{
		int[] arr = {6, -3, 9,3,6,-7,5,0};
		
		Sample sample= new Sample();
		
		int min = sample.getMin(arr);
		
		assertEquals(-7, min);
	}
	
	@Test
	public void test3()
	{
		int x=12;
		
		Sample sample=new Sample();
		
		boolean even = sample.isEven(x);
		
		assertEquals(true, even);
	}
	
	@Test
	public void test4() {
		int a=6,v=8;
		
		Sample sample = new Sample();
		
		int addition = sample.add(a, v);
		
		assertEquals(14, addition);
	}

}
