package p1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.bootcamp.testing.Sample;

public class SampleTest {
	
	@Test
	void test_getMin()
	{
		int[] arr = {6,3,9,3,6,7,5};
		
		Sample sample= new Sample();
		
		int min= sample.getMin(arr);
		
		assertEquals(3, min);
	}
	
	@Test
	void test_getMin2()
	{
		int[] arr = {6, -3, 9,3,6,-7,5,0};
		
		Sample sample= new Sample();
		
		int min = sample.getMin(arr);
		
		assertEquals(-7, min);
	}

}
