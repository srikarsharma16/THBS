import java.sql.*;

public class InsertDemo {
	public static void main(String[] args) throws Exception {
		
		//int id=02;
		String name= "Deepak";
		//String password="6754";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/boot_camp_db","root","pass@word1");
		
		//String sql="INSERT INTO emp VALUES (?,?)";
		//String sql="UPDATE emp SET name=? where password=?";
		//String sql="UPDATE emp SET password=? where name=?";
		String sql="DELETE from emp where name=?";
		
		PreparedStatement ps= connection.prepareStatement(sql);
		
		//ps.setInt(1, id);
		ps.setString(1, name);
		//ps.setString(1, password);
		
		ps.executeUpdate();
		
		ps.close();
		
		connection.close();
		
		//System.out.println("Record Inserted Successfully");
		//System.out.println("Record Updated Successfully");
		System.out.println("Record Deleted Successfully");
		
	}

}
