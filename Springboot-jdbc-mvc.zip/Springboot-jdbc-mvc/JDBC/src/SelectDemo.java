import java.sql.*;

public class SelectDemo {
	public static void main(String[] args) throws Exception {
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/boot_camp_db","root","pass@word1");
		
		
		String sql="SELECT * from emp";
		
		PreparedStatement ps= connection.prepareStatement(sql);
		
		ResultSet rs= ps.executeQuery();
		System.out.println("Name,Password\n");
		
		while(rs.next())
		{
			rs.getString("name");
			String name = rs.getString("name");
			String password= rs.getString("password");
			
			System.out.println(name+","+password);
		}
		
		rs.close();
		ps.close();
		
		connection.close();
		
	
		System.out.println("\nRecord Retrived  Successfully");
		
	}

}
