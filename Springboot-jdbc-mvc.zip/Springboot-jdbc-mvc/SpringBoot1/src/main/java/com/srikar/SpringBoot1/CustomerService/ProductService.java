package com.srikar.SpringBoot1.CustomerService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srikar.SpringBoot1.dao.ProductDAO;
import com.srikar.SpringBoot1.model.Customer;
import com.srikar.SpringBoot1.model.Product;

@Service
public class ProductService {
	
	
	@Autowired
	private ProductDAO productDAO;
	
	public void add(Product product) {
		
		productDAO.add(product);
	}
	
	public List<Product> getAllProducts() {
		return productDAO.findAll();
	}

	public Product getProductById(long id) {
		for (Product productDB : getAllProducts()) {
			if(productDB.getId() == id) {
				return productDB;
			}
		}
		return null;
	}

	public void edit(Product product) {
		
		productDAO.update(product);
		
	}
	
	public void deleteProductById(long id) {
		 
        productDAO.delete(id);
 
    }
	

}
