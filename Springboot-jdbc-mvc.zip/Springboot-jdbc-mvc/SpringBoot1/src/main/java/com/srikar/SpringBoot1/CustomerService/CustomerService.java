package com.srikar.SpringBoot1.CustomerService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srikar.SpringBoot1.dao.CustomerDAO;
import com.srikar.SpringBoot1.model.Customer;
import com.srikar.SpringBoot1.model.Login;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerDAO customerDAO;
	

	
	
	public void add(Customer customer) {
		
		System.out.println("Adding customer");
		customerDAO.add(customer);
		
		
		
		
	}
	
	public List<Customer> getAllCustomers() {
		
		return customerDAO.findAll();
	}
	


	public boolean validate(Login login) {
		String email= login.getEmail();
		String password = login.getPassword();
		for (Customer customer : getAllCustomers()) {
			if (customer.getEmail().equals(email) && customer.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
		
	}
	

}
