package app;

import org.springframework.stereotype.Component;

@Component

public class Bike {
	
	public void move()
	{
		System.out.println("Bike is moving");
	}

}
